package com.abzora.transfertpos;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
